%% Prep work
clear all; close all; clc;
addpath('../data');
C  = psconstants;
opt = psoptions;
ps  = case9_ps;

ps = runPowerFlow(ps);
% build the machine variables
ps.mac = get_mac_state(ps,'salient');

%% Build an event matrix
event = zeros(3,C.ev.cols);
% start
event(1,[C.ev.time C.ev.type]) = [0 C.ev.start];
% trip a branch
event(2,[C.ev.time C.ev.type]) = [1 C.ev.trip_branch];
event(2,C.ev.branch_loc) = 8;
% set the end time
event(3,[C.ev.time C.ev.type]) = [20 C.ev.finish];

%% run the simulation
[outputs,ps] = simgrid(ps,event,'sim_case9',opt);

%% print the results
fname = outputs.outfilename;
[t,delta,omega,Pm,Eap,theta,Vmag] = read_outfile(fname,ps);
omega_0 = 2*pi*ps.frequency;
omega_pu = omega / omega_0;

figure(1); clf;
subplot(3,1,1); hold on;
plot(t',delta');
plot(t',omega_pu');

ylabel('delta');

subplot(3,1,2);
plot(t',theta');
ylabel('theta');

subplot(3,1,3);
plot(t',Vmag');
ylabel('Vmag');
