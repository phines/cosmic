COSMIC Release 0.1 - README

There are two scripts that test the features of cosmic 0.1:

1. test_steady_state.m : This driver integrates a steady state case with 975 buses for 500 seconds.
Additionally, it verifies the derivatives of the differential and algebraic equations and their
residuals.

2. test_discrete_change.m : This driver simulates the opening and closing of a transmission line on
a case with 351 buses. The line is disconnected at t = 5 sec. and put back in service at t = 6 sec.
The total integration time is 40 sec.