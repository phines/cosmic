function [ps,relay_event,t_out,X,Y] = simgrid_interval(ps,t,t_next,x0,y0)
% usage: [ps,relay_event,t_out,X,Y] = simgrid_interval(ps,t,t_next,x0,y0)
% integrate PS DAEs from t to t_next, recursively if endogenous events
%
% inputs:
%  ps - power system structure, see psconstants.
%  t  - initial simulation time.
%  t_next - end simulation time assuming no relay events.
%  x0 and y0 describe the current state of the system
%
% outputs:
%  ps - the power systems structure at the end of the simulation.
%  relay_event - returns info in case of endogenous event
%

% constants and data
C           = psconstants;
n           = size(ps.bus,1);
n_macs      = size(ps.mac,1);
m           = size(ps.branch,1);
ix          = get_indices(n,n_macs,m);
mac_bus_i   = ps.bus_i(ps.mac(:,1));
xy0         = [x0;y0];

% check whether the last relay event splitted the system
br_status           = ps.branch(:,C.br.status) == C.CLOSED;
[graph_nos,n_subs]  = findSubGraphs(ps.bus(:,C.bu.id), ps.branch(br_status,C.br.f:C.br.t));

if n_subs > 1
    % the network was partitioned
    if any(graph_nos>2), error('system partitioned in more than 2 islands... '); end;
    
    % get ps structures for the two subnets
    net2 = logical(graph_nos - 1);
    net1 = ~net2;
    ps1  = subsetps(ps, net1);  ps2  = subsetps(ps, net2);      % inherit ps.mac, ps.gen etc
    

% integrate interval 
clear fn_fg;
fn_fg = @(t,xy) differential_algebraic(t,xy,ix.nx,ps);
mass_matrix = sparse(1:ix.nx,1:ix.nx,1,ix.nx+ix.ny,ix.nx+ix.ny);
options = odeset(   'Mass',mass_matrix, ...
                    'MassSingular','yes', ...
                    'Jacobian', @(t,xy) get_jacobian(t,xy,ix.nx,ps), ...
                    'Stats','off', ... 
                    'NormControl','off');                    
odeout  = ode23t(fn_fg,[t t_next],xy0,options);
t_out   = odeout.x;
x_rows  = (1:ix.nx);
y_rows  = (ix.nx+1):(ix.nx+ix.ny);
X       = odeout.y(x_rows,:);
Y       = odeout.y(y_rows,:);
x_end   = X(:,end);
y_end   = Y(:,end);

% store data back into the ps structure
delta_sys   = y_end(ix.y.delta_sys);
mac_Thetas  = y_end(ix.y.theta(mac_bus_i));
delta_m     = x_end(ix.x.delta) + delta_sys - mac_Thetas;
ps.mac(:,C.mac.delta_m)     = delta_m;
ps.mac(:,C.mac.omega)       = x_end(ix.x.omega_pu)*2*pi*ps.frequency;
ps.mac(:,C.mac.Pm)          = x_end(ix.x.Pm);
ps.mac(:,C.mac.Eap)         = x_end(ix.x.Eap);
ps.bus(:,C.bus.Vmag)        = y_end(ix.y.Vmag);
ps.bus(:,C.bus.Vang)        = y_end(ix.y.theta)*180/pi;

% check to see if we got all the way to the end of the time-period
if t_out(end)<t_next
    error('couldn''t integrate to tend, relay switched?');
end

return
% the stuff below isn't really done yet
% check for new relay events and record them
%if abs(t_next - t_out(end)) > 1e-6
%        fprintf(fid,'...%d successful steps\n',odeout.stats.nsteps);
%        fprintf(fid,'...%d failed attempts\n',odeout.stats.nfailed);
%        fprintf(fid,'relay triggered at t = %d. ???????????',odeout.x(end));
%        fprintf(fid,'integrated PS DAE from t = %d to t = %d.\n',t,odeout.x(end));
%        relay_event = odeout.x(end);
%else
%        fprintf(fid,'...%d successful steps\n',odeout.stats.nsteps);
%        fprintf(fid,'...%d failed attempts\n',odeout.stats.nfailed);
%        fprintf(fid,'integrated PS DAE from t = %d to t = %d.\n',t,t_next);
%        relay_event = [];
%end
