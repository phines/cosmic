function [outputs,ps] = simgrid(ps,event,outfilename,opt)
% usage: [outputs,ps] = simgrid(ps,event,outfilename,opt)
% Perform a cascading failure simulation
% Inputs:
%  ps - PowerSystem structure. See psconstants.
%  event - a matrix defining the exogenous events to simulate. See psconstants.
%  outfilename - the name for the output file
%  opt - an option structure. See psoptions.
% Outputs:
%  outputs. a Structure of output data, including the following:
%    .success - a bool flag indicating whether we were able to simulate to the end.
%    .t_simulated - vector of time periods in the final results.
%    .outfilename - the name of the file where the results are stored.
%    .demand_lost - the amount of demand that was shed during the simulation.
%    .computer_time - the amount of wall-clock time required to perform this simulation
%  ps - the power systems structure at the end of the simulation.

%% process the inputs
if nargin<2 || isempty(event)
    event = ps.event;
end
if nargin<3 || isempty(outfilename)
    outfilename = 'outfile.csv';
end
if nargin<4 || isempty(opt)
    opt = psoptions;
end

%% edit the output file name
outfilename = sprintf('%s_%s.csv',strtok(outfilename,'.'),datestr(now,30));

%% prepare the outputs
outputs.success         = false;
outputs.t_simulated     = [];
outputs.outfilename     = outfilename;  % should this be more intelligent
outputs.demand_lost     = 0;
outputs.computer_time   = [];

%% other prep work
C       = psconstants;
verbose = opt.verbose;

%% check the event matrix
event = sortrows(event);
if event(1,C.ev.type)~=C.ev.start
    error('First event should be a start event');
end
t_0   = event(1,1);
event = event(2:end,:); % remove the start event
if event(end,C.ev.type)~=C.ev.finish
    error('Last event should be a finish event');
end
t_end = event(end,1);
t = t_0;

%% print something
out = fopen(outfilename,'w');
if isempty(out)
    error('simgrid:err','Could not open outfile: %s',outfilename);
end
fprintf(out,'Starting simulation at t = %g\n',t);
fclose(out);
if opt.verbose
    fprintf('Starting simulation at t = %g\n',t);
    fprintf('Writing results to %s\n',outfilename);
end

%% initialize the relays in the system
[ps,tempmax]    = get_relay_state(ps);

%% get the initial machine state, x, y
% build the Ybus
if ~isfield(ps,'Ybus')
    [ps.Ybus,ps.Yf,ps.Yt] = getYbus(ps,false);
end
% machine matrix
ps.mac = get_mac_state(ps,'salient');
% build x and y
[x,y] = get_xy(ps);

%% step through the simulation
event_no = 1;
while t<t_end
    % process exogenous discrete events at this time period
    while event(event_no,1)<=t
        [ps,y,changed] = process_event(ps,event(event_no,:),x,y,verbose);
        event_no = event_no+1;
        if changed
            t = t + opt.sim.t_eps;
            write_state(outfilename,t,x,y);
        end
    end
    % find the next time interval
    t_next = event(event_no,1);
    % try to simulate between t and t_next
    if opt.verbose
        fprintf('Simulating from t=%g s to t=%g s\n',t,t_next);
    end
    [ps,relay_event,t_vector,X,Y] = simgrid_interval(ps,t,t_next,x,y);
    write_state(outfilename,t_vector,X,Y);
    % if there was a relay event, apply it
    if ~isempty(relay_event)
        error('Not finished yet');
        ps = process_event(ps,relay_event);
        t_event = relay_event(1);
        t_next = t_event + opt.t_eps;
        write_state(outfilename,t_vector,X,Y);
    end
    t = t_next;
end

%% clean up
if opt.verbose
    fprintf('Completed simulation from %d sec. to %d sec. \n',t,t_next);
end


