function [x,y] = get_xy(ps)
% this function gets the x and y vectors from the data in ps
% this is used for the full/nonlinear grid model

% get some constants
C  = psconstants;
n  = size(ps.bus,1);
ng = size(ps.gen,1);
m  = size(ps.branch,1);
ix = get_indices(n,ng,m);

% get data from the ps structure
mac_bus_i   = ps.bus_i(ps.mac(:,1));
omega_0     = 2*pi*ps.frequency;
Vmag        = ps.bus(:,C.bu.Vmag);
theta       = ps.bus(:,C.bu.Vang)*pi/180;
delta       = ps.mac(:,C.ma.delta_m) + theta(mac_bus_i);
omega_pu    = ps.mac(:,C.ma.omega)/omega_0;
Pm          = ps.mac(:,C.ma.Pm);
Eap         = ps.mac(:,C.ma.Eap);

% build x
x = zeros(ix.nx,1);
x(ix.x.delta)    = delta;
x(ix.x.omega_pu) = omega_pu;
x(ix.x.Pm)       = Pm;
x(ix.x.Eap)      = Eap;

% build y
y = zeros(ix.ny,1);
y(ix.y.Vmag)        = Vmag;
y(ix.y.theta)       = theta;
y(ix.y.delta_sys)   = 0;