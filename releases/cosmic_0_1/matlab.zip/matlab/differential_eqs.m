function [f,df_dx,df_dy] = differential_eqs(t,x,y,ps) %#ok<INUSL>
% usage: [f,df_dx,df_dy] = differential_eqs(t,x,y,ps)
% differential equation that models the elements of the power system
%
% inputs:
%   t  -> time in seconds
%   x  -> [delta omega Pm Eap] for each machine and [temp] for each branch
%   y  -> [Vmag Theta]
%   ps -> power system structure
%
% outputs: 
%   f(1) -> ddelta_dt
%   f(2) -> domega_dt
%   f(3) -> dPm_dt
%   f(4) -> dEa_dt
%   f(5) -> dtemp_dt

% constants
C           = psconstants;
n           = size(ps.bus,1);
ng          = size(ps.mac,1);
m           = size(ps.branch,1);
ix          = get_indices(n,ng,m);

% extract parameters from ps
Xdps    = ps.mac(:,C.ma.Xdp);
Xqs     = ps.mac(:,C.ma.Xq);
Ds      = ps.mac(:,C.ma.D);
Ms      = ps.mac(:,C.ma.M);
omega_0 = 2*pi*ps.frequency;

% extract differential variables
deltas      = x(ix.x.delta);
omegas_pu   = x(ix.x.omega_pu);
Pms         = x(ix.x.Pm);
Eaps        = x(ix.x.Eap);
temps       = x(ix.x.temp);

% extract algebraic variables and fix the slack bus angle
mac_buses   = ps.mac(:,C.mac.gen);
mac_bus_i   = ps.bus_i(mac_buses);

Vmags       = y(ix.y.Vmag);
Thetas      = y(ix.y.theta);
mac_Vmags   = Vmags(mac_bus_i);
mac_Thetas  = Thetas(mac_bus_i);

% machine angles, relative to the bus angles
delta_sys   = y(ix.y.delta_sys);
delta_m     = deltas + delta_sys - mac_Thetas;

% calculate Pe: Eq. 7.81 from Bergen & Vittal
Pes = (Eaps.*mac_Vmags./Xdps).*sin(delta_m) +...
    mac_Vmags.^2./2.*(1./Xqs-1./Xdps).*sin(2*delta_m);
% calculate Efd from the exciter model
%Efds = ps.exc(:,C.ex.Efd); % at least for now

% initialize output
f = zeros(length(x),1);

% calculate swing equations
f(ix.f.delta_dot) = omega_0.*(omegas_pu-1);
f(ix.f.omega_dot) = (Pms - Pes - Ds.*(omegas_pu-1))./Ms;
% calculate the first derivative of Eap
%  We will implement this later, with the exciter
%f(ix.f.Eap_dot)   = 0; %(Efds - Eas)./Tdops;

% calculate the temperature change
%V                   = Vmags .* exp(1i*Thetas);
%If                  = ps.Yf * V;
%Imag_f              = abs(If);
%f(ix.f.temp_dot)    = Imag_f.^2 - C.K*temps;

% output df_dx and df_dy if requested
if nargout>1
    % build df_dx
    % Pes = (Eaps.*mac_Vmags./Xdps).*sin(delta_m) +...
    %  mac_Vmags.^2./2.*(1./Xqs-1./Xdps).*sin(2*delta_m);
    dPg_ddelta = (Eaps.*mac_Vmags./Xdps).*cos(delta_m) + ...
                  mac_Vmags.^2.*(1./Xqs-1./Xdps).*cos(2*delta_m);
    dFswing_ddelta_values = -dPg_ddelta./Ms;
    dFswing_domega_values = -Ds./Ms;
    dFswing_dPm_values    = 1./Ms;
    dFswing_dEa_values    = -sin(delta_m).*mac_Vmags./(Ms.*Xdps);
    
    % assemble df_dx
    df_dx = sparse(ix.nx,ix.nx);
    % dFswing_ddelta
    df_dx = df_dx + sparse(ix.f.omega_dot,ix.x.delta,dFswing_ddelta_values,ix.nx,ix.nx);
    % dFswing_domega
    df_dx = df_dx + sparse(ix.f.omega_dot,ix.x.omega_pu,dFswing_domega_values,ix.nx,ix.nx);
    % dFswing_dPm
    df_dx = df_dx + sparse(ix.f.omega_dot,ix.x.Pm,dFswing_dPm_values,ix.nx,ix.nx);
    % dFswing_dEa
    df_dx = df_dx + sparse(ix.f.omega_dot,ix.x.Eap,dFswing_dEa_values,ix.nx,ix.nx);
    % dFdelta_dot_domega
    df_dx = df_dx + sparse(ix.f.delta_dot,ix.x.omega_pu,omega_0,ix.nx,ix.nx);
    % dFtemp_dot_dtemp
    %df_dx = df_dx + sparse(ix.f.temp_dot,ix.x.temp,-C.K,ix.nx,ix.nx);
end
if nargout>2
    % build df_dy (change in f wrt the algebraic variables)
    dPg_dtheta = Eaps.*sin(delta_m)./Xdps + mac_Vmags.*(1./Xqs-1./Xdps).*sin(2*delta_m);
    dFswing_dVmag_values = -(dPg_dtheta)./Ms;
    % assemble df_dy
    cols = ix.y.Vmag(mac_bus_i);
    df_dy = sparse(ix.f.omega_dot,cols,dFswing_dVmag_values,ix.nx,ix.ny);
    cols = ix.y.theta(mac_bus_i);
    df_dy = df_dy + sparse(ix.f.omega_dot,cols,-dFswing_ddelta_values,ix.nx,ix.ny);
    cols = ix.y.delta_sys;
    df_dy = df_dy + sparse(ix.f.omega_dot,cols,dFswing_ddelta_values,ix.nx,ix.ny);
end
