function index = get_indices(n_bus,n_macs,n_branches,interleave)
% usage: index = get_indices(n_bus,n_macs,n_branches,interleave)
% produces a structure that helps us to know where stuff is in x,y,f,g

if nargin < 4, interleave = true; end     % debugging flag to test different reorderings of the x and y variables

% differential (generator,exciter,governor,relays) variable index
if interleave
    index.x.delta       = (1:4:4*n_macs);
    index.x.omega_pu    = (2:4:4*n_macs);
    index.x.Pm          = (3:4:4*n_macs);
    index.x.Eap         = (4:4:4*n_macs);
    index.x.temp        = (1:n_branches) + n_macs*4;
else
    index.x.delta       = (1:n_macs);
    index.x.omega_pu    = (1:n_macs) + n_macs;
    index.x.Pm          = (1:n_macs) + n_macs*2;
    index.x.Eap         = (1:n_macs) + n_macs*3; 
    index.x.temp        = (1:n_branches) + n_macs*4;
end
    
index.nx            = n_macs*4 + n_branches;
index.x.omega       = index.x.omega_pu; 

% differential equation index is the same as x index
index.f.delta_dot = index.x.delta;
index.f.omega_dot = index.x.omega_pu;
index.f.Pm_dot    = index.x.Pm;
index.f.Eap_dot   = index.x.Eap;
index.f.temp_dot  = index.x.temp;

index.nf = index.nx;
index.f.swing = index.f.omega_dot;

% algebraic variable index
if interleave
    index.y.Vmag    = (1:2:2*n_bus);
    index.y.theta   = (2:2:2*n_bus); 
else
    index.y.Vmag    = (1:n_bus);
    index.y.theta   = (1:n_bus) + n_bus;
end
index.y.delta_sys = n_bus*2 + 1;
index.ny = 2*n_bus + 1;

% algebraic function index
index.g.P       = index.y.Vmag;
index.g.Q       = index.y.theta;
index.g.slack   = index.y.delta_sys;

index.ng = index.ny;
return
