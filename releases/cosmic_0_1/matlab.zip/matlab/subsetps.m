function ps = subsetps( ps, bus_subset )
% usage: ps = subsetps( ps, bus_subset )
% subset a power system given the nodes specified in 
% "subset."  The input "subset" can be either a binary/logical vector
% with one entry per bus, or a list of bus numbers

if islogical(bus_subset)
    bus_nos = ps.bus(bus_subset,1);
else
    bus_nos = bus_subset;
    bus_subset = ismember( ps.bus(:,1), bus_nos );    
end
% subset the buses
ps.bus = ps.bus(bus_subset,:);

% figure out which branches to keep
F = ps.branch(:,1);
T = ps.branch(:,2);
br_keep = ismember(F,bus_nos) & ismember(T,bus_nos);
% subset the branches
ps.branch = ps.branch(br_keep,:);

% subset the generators
ge_keep = ismember(ps.gen(:,1),bus_nos);
ps.gen    = ps.gen(ge_keep,:);

% subset the shunts
if isfield(ps,'shunt')
    sh_keep = ismember(ps.shunt(:,1),bus_nos);
    ps.shunt = ps.shunt(sh_keep,:);
end

% rebuild the bus index
ps = updateps(ps);
