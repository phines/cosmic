function y_new = solve_algebraic(t,x,y,ps,verbose)
% usage: y_new = solve_algebraic(t,x,y,ps,verbose)
% solves the algebraic system (g) after a discrete change
% this assumes that ps.Ybus has been updated with the new discrete state

% set up the function to be solved
opt = numerics_options;
opt.nr.verbose = verbose;
g_handle = @(y) algebraic_eqs_only(t,x,y,ps);
[y_new,success] = nrsolve(g_handle,y,opt);

if ~success
    y_new = [];
    keyboard
end
