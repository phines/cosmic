 function [ps,converged,islands] = runPowerFlow(ps,opt)
% perform a power flow calculation on the power system
% inputs:
%  ps - a ps structure
%  opt - a structure of options defined in psoptions.m

%% check the inputs0
if nargin<2
    opt = psoptions;
end

if opt.pf.update
    ps = updateps(ps);
end

%% call the new solver
[ps,converged,islands] = newpf(ps,opt);
