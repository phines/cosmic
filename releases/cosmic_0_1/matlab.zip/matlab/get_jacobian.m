function [J,df_dx,df_dy,dg_dx,dg_dy] = get_jacobian(t,xy,nx,ps)
% usage: [J,df_dx,df_dy,dg_dx,dg_dy] = get_jacobian(t,xy,nx,ps)

x = xy(1:nx);
y = xy((1+nx):end);

[~, df_dx,df_dy] = differential_eqs(t,x,y,ps);
[~, dg_dx,dg_dy] = algebraic_eqs(t,x,y,ps);

J = [df_dx df_dy; dg_dx dg_dy];
