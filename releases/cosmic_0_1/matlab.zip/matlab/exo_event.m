function [value,isterminal,direction] = exo_event (~,xy,ix,tempmax)
% usage: [value,isterminal,direction] = exo_event (~,xy,ix,tempmax)
% defines an exogenous event (relay) that will stop the DAE integration

value   =   tempmax - xy(ix.x.temp);               % zero crossing at maximum temperature

isterminal  =    ones(size(xy(ix.x.temp),1),1);    % terminate integration
direction   =   -ones(size(xy(ix.x.temp),1),1);    % to detect crossing from + to -
