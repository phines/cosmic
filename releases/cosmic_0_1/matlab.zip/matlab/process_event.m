function [ps,y_new,recalc_y] = process_event(ps,event,x,y,verbose)
% usage: [ps,y_new,recalc_y] = process_event(ps,event,x,y,verbose)
% process the event specified in the event vector (one row of an event
% matrix)


if size(event,1)>1 
    error('Can only process one event at a time');
end

recalc_y = false;
y_new = y;

C = psconstants;
t = event(C.ev.time);

switch event(C.ev.type)
    case C.ev.start % three phase to ground fault by default
        if verbose
            fprintf('Simulation start event');
        end

    case C.ev.fault % three phase to ground fault by default
        error('Faults not supported yet');
        
    case C.ev.trip_branch
        br = event(C.ev.branch_loc);
        if ps.branch(br,C.br.status)~=0
            ps.branch(br,C.br.status) = 0;
            recalc_y = true;
            if verbose
                fprintf(' branch %d tripped at t = %.2f\n',br,t);
            end
        end
        
    case C.ev.close_branch
        br = event(C.ev.branch_loc);
        if ps.branch(br,C.br.status)~=1
            ps.branch(br,C.br.status) = 1;
            recalc_y = true;
            if verbose
                fprintf(' branch %d closed at t = %.2f\n',br,t);
            end
        end
            
    case C.ev.trip_bus
        bus_no = event(1,C.ev.bus_loc);
        br_set = any( ps.branch(:,1:2)==bus_no, 2 );
        ps.branch(br_set,C.br.status) = 0;
        % trip gens and shunts at this bus
        ps.gen(ps.gen(:,1)==bus_no,C.gen.status) = 0;
        ps.shunt(ps.shunt(:,1)==bus_no,C.shunt.status) = 0;
        recalc_y = true;
        if opt.verbose
            fprintf(' bus %d tripped at t = %.2f\n',bus_no,t);
        end
        
    case C.ev.trip_gen
        g = event(C.ev.gen_loc);
        if ps.gen(g,C.gen.status)~=0
            ps.gen(g,C.gen.status) = 0;
            ps.gen(g,C.Pg) = 0;
            ps.gen(g,C.Qg) = 0;
            if opt.verbose
                fprintf(' gen %d tripped at t = %.2f\n',g,t);
            end
            recalc_y = true;
        end
    otherwise
        error('Unknown event type');
end

%% if needed, solve the algebraic equations
if recalc_y
    % TODO: delete lines from the Ybus, rather than resolve the whole thing
    ps.Ybus = getYbus(ps,false);
    y_new = solve_algebraic(t,x,y,ps,verbose);
    if isempty(y_new)
        error('Could not solve the algebraic system after a discrete change');
    end
end

