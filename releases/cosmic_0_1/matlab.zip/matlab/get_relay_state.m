function [ps,tempmax] = get_relay_state(ps)
% usage: [ps,tempmax] = get_relay_state(ps)
% gets/resets the status of the relays for the system described in ps

C = psconstants;

ps.branch(:,C.br.rateA)    = 0.2127775./ps.branch(:,C.br.X);
ps.branch(:,C.br.rateB)    = 1.1.*ps.branch(:,C.br.rateA);
ps.branch(:,C.br.temp)     = (ps.branch(:,C.br.Imag_f).^2)./(C.K);

tempmax = (ps.branch(:,C.br.rateA).^2)./(C.K);
