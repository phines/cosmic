function [t,delta,omega,Pm,Eap,theta,Vmag] = read_outfile(fname,ps)
% usage: [t,delta,omega,Pm,Eap,theta,Vmag] = read_outfile(fname,ps)

n_bus = size(ps.bus,1);
n_mac = size(ps.mac,1);
ix = get_indices(n_bus,n_mac);

data = csvread(fname,1);

t = data(:,1);
X = data(:,1+(1:ix.nx));
Y = data(:,1+ix.nx+(1:ix.ny));

% X vars
delta = X(:,ix.x.delta);
omega = X(:,ix.x.omega)*2*pi*ps.frequency;
Pm    = X(:,ix.x.Pm);
Eap   = X(:,ix.x.Eap);

% Y vars
theta = Y(:,ix.y.theta);
Vmag  = Y(:,ix.y.Vmag);
