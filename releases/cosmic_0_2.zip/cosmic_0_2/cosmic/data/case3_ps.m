function ps = case3_ps

ps.baseMVA = 100.000000;

ps.bus = [...
%ID type Pd Qd Gs Bs area Vmag Vang basekV zone Vmax Vmin lam_P lam_Q mu_Vx mu_Vn locX locY 
 1 3 0 0 0 0 1 1.05 0 16.5 1 1.1 0.9 0 0 0 0 0 0;
 2 2 0 0 0 0 1 1 0 16.5 1 1.1 0.9 0 0 0 0 0 0;
 3 1 0 0 0 2 1 1 0 16.5 1 1.1 0.9 0 0 0 0 0 0;
];

ps.branch = [...
%from to R X B rateA rateB rateC tap shift status 
 1 3 0 0.05 0 250 250 250 1 0 1 0 0 0 0 0 0 0 0 0 0 0;
 2 3 0 0.03999 0 250 250 250 1 0 1 0 0 0 0 0 0 0 0 0 0 0;
 2 3 0 0.03999 0 300 300 300 1 0 1 0 0 0 0 0 0 0 0 0 0 0;
];

ps.gen = [...           
%bus Pg Qg Qmax Qmin Vsp mBase status Pmax Pmin mu_Px mu_Pn mu_Qx mu_Qn type cost 
 1 71.6 10 300 -300 1.04 555.5 1 250 10 0 0 0 0 3 5 1;
 2 163 10 300 -300 1.025 700 1 300 10 0 0 0 0 2 1.2 0;
];

ps.shunt = [...          
%bus P Q frac_S frac_Z status type value 
 3 900 300 1 0 1 1 1000 0;
];

ps.mac = [...
%gen r Xd Xdp Xdpp Xq Xqp Xqpp D M Ea Eap Pm delta omega T'do
 1 0 1.8 0.3 0.217 1.76 0.610 0.217 0.5 9.06   1.2 0 0 0 0 0 7.8;
 2 0 1.8 0.3 0.217 1.76 0.610 0.217 0.5 13.06  1.2 0 0 0 0 0 7.8;
];

ps.exc=[...
%gen type ka Ta Tb Ke  Te  Kf Tf Aex Bex Urmin Urmax Vref
  1   1   0  1  10 100 0.1 0  0  0   0   0     0 1.0508
  2   1   0  1  10 100 0.1 0  0  0   0   0     0 1.0429];      

ps.gov=[...
%gen type R    TSR TSM Tt LCmax LCmin Pmax Pmin Pref
 1    1   0.05 0.1 0.3 2  0.1   -1    1    0 0.7164
 2    1   0.05 0.1 0.3 2  0.1   -1    1    0 1.63];
