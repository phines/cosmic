function event = unit_test_case9_events

event = [...
%time type bus_loc branch_loc gen_loc shunt_loc relay_loc 
 0 0 0 0 0 0 0;
 10 4 0 6 0 0 0;
 1800 1 0 0 0 0 0;
];

