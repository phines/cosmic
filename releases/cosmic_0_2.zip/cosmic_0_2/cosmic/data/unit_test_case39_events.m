function event = unit_test_case39_events

event = [...
%time type bus_loc branch_loc gen_loc shunt_loc relay_loc 
 0 0 0 0 0 0 0;
 50 4 0 32 0 0 0;
 100 4 0 33 0 0 0;
 200 4 0 24 0 0 0;
 300 4 0 23 0 0 0;
 1800 1 0 0 0 0 0;
];

