function [value,isterminal,direction] = endo_event(~,xy,ix,ps)
% usage: [value,isterminal,direction] = endo_event(~,xy,ix,ps)
% defines an exogenous event (relay) that will stop the DAE integration

% constants and settings
C = psconstants;
Vmag_threshold          = 0.8;   % undervoltage threshold
omega_pu_threshold      = 0.95;  % underfrequency threshold
dist_zone1_threshold    = 0.9;   % distance relay zone 1 setting

% extract some info from the inputs
x               = xy(1:ix.nx); 
y               = xy(ix.nx+1:end);
Vmags           = y(ix.y.Vmag);
Thetas          = y(ix.y.theta);
V               = Vmags .* exp(1i*Thetas);
If              = ps.Yf * V;
Imag_f          = abs(If);
temp_threshold  = ps.relay(ix.re.temp,C.re.threshold);
F               = ps.bus_i(ps.branch(:,C.br.from));
R               = ps.branch(:,C.br.R);
X               = ps.branch(:,C.br.X);
y_threshold     = 1./(dist_zone1_threshold.*abs(R+1i*X));

y_apparent      = Imag_f./Vmags(F);

% build zero crossing function
value   =   [temp_threshold     - x(ix.x.temp);                 % zero crossing at maximum temperature
             y(ix.y.Vmag)       - Vmag_threshold;               % trigger undervoltage load shedding
             x(ix.x.omega_pu)   - omega_pu_threshold;           % trigger underfrequency load shedding
             y_threshold        - y_apparent];                  % trigger zone 1 distance relay

% set directions
n_relays = size(ps.relay,1);
isterminal  =    ones(n_relays,1);    % terminate integration
direction   =   -ones(n_relays,1);    % to detect crossing from + to -
