function relay = get_relays(ps,mode)
% usage: relay = get_relays(ps,mode)
% gets the relay matrix for the system described in ps

C = psconstants;
m = size(ps.branch,1);
n = size(ps.bus,1);
n_macs = size(ps.gen,1);

ten_min_temp_constant   = 0.2127775; % calculated previously...probably should revisit.
rateA_rateB_factor      = 1.1;

if nargin<2
    mode = 'all';
end


switch mode
    case 'temperature'
        relay = zeros(m,C.relay.cols);
        br_status = ps.branch(:,C.br.status);
        relay(:,C.re.type)              = C.relay.temp;
        relay(:,C.re.setting1)          = ten_min_temp_constant./ps.branch(:,C.br.X);
        relay(:,C.re.setting2)          = rateA_rateB_factor.*relay(:,C.re.setting1);
        relay(:,C.re.threshold)         = (relay(:,C.re.setting1).^2)./(C.K);
        relay(:,C.re.state_a)           = (ps.branch(:,C.br.Imag_f).^2)./(C.K);
        relay(:,C.re.state_b)           = br_status;
        relay(:,C.re.branch_loc)        = ps.branch(:,C.br.id);
    case 'uvls'
        relay = zeros(n,C.relay.cols);
        relay(:,C.re.type) = C.relay.uvls;
        relay(:,C.re.bus_loc) = ps.bus(:,C.bu.id);
        %%%%
        % TODO: implement me
        %%%%
    case 'ufls'
        relay = zeros(n_macs,C.relay.cols);
        relay(:,C.re.type) = C.relay.ufls;
        relay(:,C.re.gen_loc) = ps.gen(:,C.ge.id);
        %%%%
        % TODO: implement me
        %%%%
    case 'distance'
        relay = zeros(m,C.relay.cols);
        relay(:,C.re.type) = C.relay.dist;
        relay(:,C.re.branch_loc) = ps.branch(:,C.br.id);
        %%%%
        % TODO: implement me
        %%%%
    otherwise
        % make relays of all types
        relay_temp = get_relays(ps,'temperature');
        relay_uvls = get_relays(ps,'uvls');
        relay_ufls = get_relays(ps,'ufls');
        relay_dist = get_relays(ps,'distance');
        relay = [relay_temp;
                 relay_uvls;
                 relay_ufls;
                 relay_dist;];
end

