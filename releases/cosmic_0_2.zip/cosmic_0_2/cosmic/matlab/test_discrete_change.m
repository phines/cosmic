%%  driver that tests discrete changes on the DAE integration 
clear all; close all; clc; C = psconstants; verbose = true;

% do not touch path if we are deploying code
if ~(ismcc || isdeployed)
    addpath('../data');
end

ps39    = case39_ps;
ps      = replicate_case(ps39,3);
ps.shunt(:,C.sh.gamma) = 0.08;
ps.mac(:,C.ma.D) = ps.mac(:,C.ma.M)./2;

% initialize the case
opt = psoptions;
opt.nr.tolerance = 1e-12;
disp('solving power flow...');
ps = runPowerFlow(ps);
[ps.Ybus,ps.Yf,ps.Yt] = getYbus(ps);

% build the machine variables
ps.mac          = get_mac_state(ps,'salient');
mac_bus_i       = ps.bus_i(ps.mac(:,1));
% initialize relays
[ps,tempmax]    = get_relay_state(ps);

% build indices
n  = size(ps.bus,1);
ng = size(ps.gen,1);
m  = size(ps.branch,1);
ix = get_indices(n,ng,m);

% build x and y
[x0,y0] = get_xy(ps);
xy0     = [x0;y0];

% discrete event time
tf = [0 5 6 40];
% fault magnitude
fault_mag = 100;

% integrate pre-event time slot 
clear fn_fg;
fn_fg   = @(t,xy) differential_algebraic(t,xy,ix.nx,ps);
mass_matrix = sparse(1:ix.nx,1:ix.nx,1,ix.nx+ix.ny,ix.nx+ix.ny);
options = odeset(   'Mass',mass_matrix, ...
                    'MassSingular','yes', ...
                    'Jacobian', @(t,xy) get_jacobian(t,xy,ix.nx,ps), ...
                    'Stats','on', ...
                    'NormControl','off');
                
odeout1 = ode23t(fn_fg,[tf(1) tf(2)],xy0,options); 

% implement the discrete event and update ps structure
ps.branch(7,C.br.status) = 0;
[ps.Ybus,ps.Yf,ps.Yt] = getYbus(ps);
% ps.shunt(:,C.sh.frac_S) = 0; 
% ps.shunt(:,C.sh.frac_Z) = 1; 
% ps.Ybus(17,17) = ps.Ybus(17,17) - 1i*fault_mag;
x1 = odeout1.y((1:ix.nx),end);
y1 = odeout1.y((ix.nx+1):(ix.nx+ix.ny),end);
ps.mac(:,C.mac.delta_m) = x1(ix.x.delta) - y1(ix.y.theta(mac_bus_i));
ps.bus(:,C.bus.Vmag)    = y1(ix.y.Vmag); 
ps.bus(:,C.bus.Vang)    = y1(ix.y.theta)/pi*180;

% solve algebraic vars and integrate within-change time slot
y1p = solve_algebraic([],x1,y1,ps,verbose);
if isempty(y1p), error('couldn''t resolve algebraic...\n'); end
xy1 = [x1;y1p];
clear fn_fg;
fn_fg   = @(t,xy) differential_algebraic(t,xy,ix.nx,ps);
mass_matrix = sparse(1:ix.nx,1:ix.nx,1,ix.nx+ix.ny,ix.nx+ix.ny);
options = odeset(   'Mass',mass_matrix, ...
                    'MassSingular','yes', ...
                    'Jacobian', @(t,xy) get_jacobian(t,xy,ix.nx,ps), ...
                    'Stats','on', ... 
                    'NormControl','off');
                    
odeout2 = ode23t(fn_fg,[tf(2) tf(3)],xy1,options);

% implement the discrete event and update ps structure
ps.branch(7,C.br.status) = 1;
[ps.Ybus,ps.Yf,ps.Yt] = getYbus(ps);
% ps.shunt(:,C.sh.frac_S) = 1; 
% ps.shunt(:,C.sh.frac_Z) = 0;
% ps.Ybus(17,17) = ps.Ybus(17,17) + 1i*fault_mag;
x2 = odeout2.y((1:ix.nx),end);
y2 = odeout2.y((ix.nx+1):(ix.nx+ix.ny),end);

% flat start: 
y2(ix.y.Vmag)  = 1;
y2(ix.y.theta) = 0;

ps.mac(:,C.mac.delta_m) = x2(ix.x.delta) - y2(ix.y.theta(mac_bus_i));
ps.bus(:,C.bus.Vmag)    = y2(ix.y.Vmag); 
ps.bus(:,C.bus.Vang)    = y2(ix.y.theta)/pi*180;

% solve algebraic vars and integrate within-change time slot
y2p = solve_algebraic([],x2,y2,ps,verbose);
if isempty(y2p), error('couldn''t resolve algebraic...\n'); end
xy2 = [x2;y2p];
clear fn_fg;
fn_fg   = @(t,xy) differential_algebraic(t,xy,ix.nx,ps);
mass_matrix = sparse(1:ix.nx,1:ix.nx,1,ix.nx+ix.ny,ix.nx+ix.ny);
options = odeset(   'Mass',mass_matrix, ...
                    'MassSingular','yes', ...
                    'Jacobian', @(t,xy) get_jacobian(t,xy,ix.nx,ps), ...
                    'Stats','on', ... 
                    'NormControl','off');
                    
odeout3 = ode23t(fn_fg,[tf(3) tf(4)],xy2,options);

% concatenate and plot outputs
plot_dyn_results([odeout1.x,odeout2.x,odeout3.x],[odeout1.y,odeout2.y,odeout3.y],ix);
%figure(1); plot([t1;t2;t3],[xy_out1(:,40+37);xy_out2(:,40+37);xy_out3(:,40+37)]);
%xlabel('time (sec)','FontSize',16); 
%ylabel('Voltage magnitude at bus 37 (V)','FontSize',16); set(gca,'FontSize',16);

%figure(2); plot([t1;t2;t3],[xy_out1(:,18)*60;xy_out2(:,18)*60;xy_out3(:,18)*60]);
%xlabel('time (sec)','FontSize',16); 
%ylabel('Gen 8 speed (Hz)','FontSize',16); set(gca,'FontSize',16);