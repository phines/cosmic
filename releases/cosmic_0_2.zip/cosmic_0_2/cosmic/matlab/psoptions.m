function opt = psoptions(opt)
% usage: opt = psoptions(opt)
% some options for the power system simulator files
if nargin==0
    opt = struct;
end

%% start with numerics options
opt = numerics_options(opt);

%% power flow options
opt.pf.tolerance = 1e-9; % convergence tolerance
opt.pf.max_iters = 20; % max power flow iterations
opt.pf.CalcIslands = 1; % iteratively calculates each island in runPowerFlow
opt.pf.CascadingPowerFlow = 0;
opt.pf.flat_start = 0;
opt.pf.load_shed_rate = 0.25; % the rate at which under frequency load shedding is done in CascadingPowerFlow mode
opt.pf.linesearch = 'backtrack';
opt.pf.update = true;

%% optimal power flow options
opt.opf.generator_commitment = 0; % switch generators on/off using MIP
opt.opf.branch_switching = 0;     % switch branches on/off using MIP

%% other options
opt.verbose = 1;
opt.seecascade = 1;

%% time-domain simulation options
opt.sim.ramp_frac = 0.05;   % fraction of generator allowed to ramp between generations
opt.sim.writelog  = true;   % write differential and algebraic variables to a file
opt.sim.dt_default = 1/30;  % default sampling rate (30Hz)
opt.sim.draw = true;
opt.sim.overload_time_limit = 10*60; % number of seconds that the branch can sit at its rateC level (PSS/E manual)
opt.sim.t_eps = 1e-6;
% legacy
opt.simdc = opt.sim;

