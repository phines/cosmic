function [g,dg_dy] = algebraic_eqs_only(t,x,y,ps)
% usage: [g,dg_dy] = algebraic_eqs_only(t,x,y,ps)
% algebraic equation that describes the network
%
% inputs:
%   t  -> time in seconds
%   x  -> [delta delta_dot Pm Eap] for each machine
%   y  -> [Vmag Theta]
%   ps -> power system structure
%
% outputs: 
%   g(1) -> Pg, real power
%   g(2) -> Qg, reactive power
%
% Equations and notation are based on Bergen & Vittal, 2000
%y = [y_sub;0];
if nargout>1
    [g,~,dg_dy] = algebraic_eqs(t,x,y,ps);
    % drop the stuff related to delta_sys???
    %dg_dy(end,:) = [];
    %dg_dy(:,end) = [];
else
    g = algebraic_eqs(t,x,y,ps);
end

% drop the stuff related to delta_sys???
%g(end) = [];
