function [ps,discrete] = process_event(ps,event,opt)
% usage: [ps,discrete] = process_event(ps,event,opt)
% process the event specified in the event vector (one row of an event matrix)


if size(event,1)>1 
    error('process_event:err','can only process one event at a time.');
end

verbose = opt.verbose;
discrete = false;   % is this a discrete event?

% extract some data
C = psconstants;
t = event(C.ev.time);
n_bus = size(ps.bus,1);

switch event(C.ev.type)
    case C.ev.start
        if verbose, fprintf(' simulation start event.'); end

    case C.ev.fault     % three phase to ground fault by default
        error('process_event:err','faults not supported yet.');
        
    case C.ev.trip_branch
        br = event(C.ev.branch_loc);
        if ps.branch(br,C.br.status) ~= 0
            ps.branch(br,C.br.status) = 0;
            discrete = true;
            % output the branch id
            br_id = ps.branch(br,C.br.id);
            if verbose, fprintf('  Branch %d tripped at t = %.2f ...\n',br_id,t); end
        end
        
    case C.ev.close_branch
        br = event(C.ev.branch_loc);
        if ps.branch(br,C.br.status) ~= 1
            ps.branch(br,C.br.status) = 1;
            discrete = true;
            if verbose, fprintf('  Branch %d closed at t = %.2f\n',br,t); end
        end
            
    case C.ev.trip_bus
        bus_no = event(1,C.ev.bus_loc);
        br_set = any( ps.branch(:,1:2)==bus_no, 2 );
        ps.branch(br_set,C.br.status) = 0;
        % trip gens and shunts at this bus
        ps.gen(ps.gen(:,1)==bus_no,C.gen.status) = 0;
        ps.shunt(ps.shunt(:,1)==bus_no,C.shunt.status) = 0;
        discrete = true;
        if verbose, fprintf('  Bus %d tripped at t = %.2f\n',bus_no,t); end
        
    case C.ev.trip_gen
        g = event(C.ev.gen_loc);
        if ps.gen(g,C.gen.status)~=0
            ps.gen(g,C.gen.status) = 0;
            ps.gen(g,C.Pg) = 0;
            ps.gen(g,C.Qg) = 0;
            if verbose, fprintf('  Gen %d tripped at t = %.2f\n',g,t); end
            discrete = true;
        end
        
    case C.ev.dist_relay
        br_loc_trigger = event(C.ev.branch_loc);
        if ps.branch(br_loc_trigger,C.br.status) ~= 0
            ps.branch(br_loc_trigger,C.br.status) = 0;
            discrete = true;
            % output the branch id
            br_trigger = ps.branch(br_loc_trigger,C.br.id);
            if verbose, fprintf('  Branch %d tripped at t = %.2f (distance relay)...\n',br_trigger,t); end
        end 
        
    case C.ev.uvls_relay
        ps.shunt(:,C.sh.factor) = max(ps.shunt(:,C.sh.factor) - opt.pf.load_shed_rate, 0);
        discrete = true; 
        bus_trigger = event(C.ev.bus_loc);
        if opt.verbose, fprintf('  Undervoltage load shedding at t = %.2f triggered by bus %d...\n',t,bus_trigger); end

    case C.ev.ufls_relay
        ps.shunt(:,C.sh.factor) = max(ps.shunt(:,C.sh.factor) - opt.pf.load_shed_rate, 0);
        discrete = true; 
        bus_trigger = event(C.ev.bus_loc);
        if opt.verbose, fprintf('  Underfrequency load shedding at t = %.2f triggered by bus %d...\n',t,bus_trigger); end

    case C.ev.temp_relay
        br_loc_trigger = event(C.ev.branch_loc);
        % update associated relay matrix
        relay_event_nos = ismember(ps.relay(:,C.re.branch_loc),br_loc_trigger);
        ps.relay(relay_event_nos,C.re.state_b) = C.OPEN;
        if ps.branch(br_loc_trigger,C.br.status) ~= 0
            ps.branch(br_loc_trigger,C.br.status) = 0;
            discrete = true;
            % output the branch id
            br_trigger = ps.branch(br_loc_trigger,C.br.id);
            if verbose, fprintf('  Branch %d tripped at t = %.2f (temperature relay)...\n',br_trigger,t); end
        end
        
    case C.ev.relay_trigger
        re_index = event(C.ev.relay_loc);
        re_type  = ps.relay(re_index,C.re.type);
        switch re_type
            case C.re.dist
                % 1) zone 1 distance relay
                br_id = ps.relay(re_index,C.re.branch_loc);
                br_index = ps.branch_i(br_id);
                % implement the event
                if ps.branch(br_index,C.br.status) ~= 0
                    ps.branch(br_index,C.br.status) = 0;
                    discrete = true;
                    % output the branch id
                    if verbose, fprintf('  Branch %d tripped at t = %.2f (distance relay)...\n',br_id,t); end
                end
                % record the event type event in ps.endo_event
                endo_event_row = [t C.ev.dist_relay 0 br_id 0 0 0];
                ps.endo_event = [ps.endo_event;endo_event_row];
            case C.re.ufls
                % TODO: Figure out how to do UFLS properly
            case C.re.uvls
                % 3) undervoltage load shedding
                bus_id = ps.relay(re_index,C.re.bus_loc);
                % implement the event
                ps.shunt(:,C.sh.factor) = max(ps.shunt(:,C.sh.factor) - opt.pf.load_shed_rate, 0);
                discrete = true;
                if opt.verbose, fprintf('  Undervoltage load shedding at t = %.2f triggered by bus %d...\n',t,bus_id); end
                % process & register event in ps.endo_event
                endo_event_row = [t C.ev.uvls_relay bus_id 0 0 0 0];
                ps = process_event(ps,endo_event_row,opt);
                ps.endo_event  = [ps.endo_event; endo_event_row];
                % also register buses where load was shed
                endo_event_matrix = [t.*ones(n_bus,1) C.ev.load_shed.*ones(n_bus,1) ps.bus(:,1) zeros(n_bus,4)];
                ps.endo_event  = [ps.endo_event; endo_event_matrix];
            case C.re.temp
                % 4) temp relay
                br_id = ps.relay(re_index,C.re.branch_loc);
                br_index = ps.branch_i(br_id);
                % implement the event
                if ps.branch(br_index,C.br.status) ~= 0
                    ps.branch(br_index,C.br.status) = 0;
                    discrete = true;
                    % output the branch id
                    if verbose, fprintf('  Branch %d tripped at t = %.2f (temperature relay)...\n',br_id,t); end
                end
                % process & register event in ps.endo_event
                endo_event_row = [t C.ev.temp_relay 0 br_id 0 0 0];
                ps.endo_event  = [ps.endo_event; endo_event_row];
        end
        
    otherwise
        error('process_event:err','Unknown event type');
end
