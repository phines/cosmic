COSMIC Release 0.2 - README

COSMIC is copyright of Paul Hines, the University of Vermont � 2012.

Check out the pdf files for documentation
